This module provide feature of Library Management.
