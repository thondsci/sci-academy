This module provide overall education management system.
    Features includes managing
        * Student
        * Faculty
        * Admission
        * Course
        * Batch
        * Standard
        * Books
        * Library
        * Lectures
        * Exams
        * Marksheet
        * Result
        * Transportation
        * Hostel
