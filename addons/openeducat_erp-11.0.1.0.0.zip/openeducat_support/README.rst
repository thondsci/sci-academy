OpenEduCat Support
==================

Change look & links in Application Planner.
